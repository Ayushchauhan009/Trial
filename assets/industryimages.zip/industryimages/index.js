import industryimg1 from "./industryimage1.png";
import industryimg2 from "./industryimage2.png";
import industryimg3 from "./industryimage3.png";
import industryimg4 from "./industryimage4.png";

export { industryimg1, industryimg2, industryimg3, industryimg4 };
